package shoot;
import java.awt.image.BufferedImage;
public class Hero extends FlyingObject{
	private static BufferedImage[] heroImages;
	 static {
		 //System.out.println(2);
		 heroImages = new BufferedImage[2];
		 heroImages[0] = loadImage("hero0.png");
		 heroImages[1] = loadImage("hero1.png");		 
	 }
	 private int life;//生命
	 private int doubleFire;//火力值
	Hero(){
		super(97,124,150,400);
		life  = 3;
		doubleFire = 0;
	}
	//将鼠标位置置于飞机中间，飞机位置随着鼠标移动而移动
	public void moveto(int x, int y) {
		 this.x = x - this.width/2;
		 this.y = y - this.height/2;
//		 this.x = x;
//		 this.y = y;
	}
	public void step() {
		//hero图片移动在getImage时已经实现了	
	}
	int index = 0;
	//当hero处于Life状态时，切换图片
	public BufferedImage getImage () {
		if (isLife()) {
			return heroImages[index++%2];
		}
		return null;
	}
	public Bullet[] shoot() {
		int xStep = this.width/4;//this.width是hero 的width，
		int yStep = 20;//Hero和bullet 之间的间隔为20个pixel
		if(doubleFire > 1) {
			Bullet[] bs = new Bullet[2];
			bs[0] = new Bullet(this.x+1*xStep,this.y-yStep);
			bs[1] = new Bullet(this.x+3*xStep,this.y-yStep);
			doubleFire -= 2;
			return bs;
		}else {
			Bullet[] bs = new Bullet[1];
			bs[0] = new Bullet(this.x+2*xStep,this.y-yStep);
			return bs;
		}
	}
	/*成员变量私有化无法调用，通过方法实现改变成员变量*/
	public void addLife() {
		life++;
	}
	
	public void addDoubleFire() {
		doubleFire += 40;
	}
	public void subtractLife() {
		life--;
	}
	/*成员变量私有化无法调用，通过方法获得成员变量*/
	public int getLife() {
		return life;
	}
	public int getDoubleFire() {
		return doubleFire;
	}
	public void clearDoubleFire() {
		doubleFire = 0;
	}
}
