package shoot;
//得分
public interface Enemy {
	int getScore();
}
