package shoot;
//奖励
public interface Award {
	int DOUBLE_FIRE = 0;//火力值
	int LIFE = 1;//命
	int getAwardType();
	
	
}
