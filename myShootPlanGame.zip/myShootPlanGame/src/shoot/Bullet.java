package shoot;
import java.awt.image.BufferedImage;
public class Bullet extends FlyingObject{
	private static BufferedImage bulletImage;
	static {
		bulletImage = loadImage("bullet.png");
	}
	private int speed;
	Bullet(int x, int y){
		super(8,14,x,y);	
		speed = 2;
		
	}
	//子弹的移动
	public void step() {
		y -= speed;
	}
	//重写子弹的getImage方法
	public BufferedImage getImage () {
		if (isLife()) {
			
			return bulletImage;
		}else if (isDead()){
			state = REMOVE;	
		}
		return null;
	
	}
	public boolean outOfBounds() {
		return this.y <= -this.height;
	}
}
