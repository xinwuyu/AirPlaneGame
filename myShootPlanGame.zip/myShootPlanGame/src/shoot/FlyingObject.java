/*
 * 将多个对象相同的各个属性和方法抽象在同一个超类
 * */
package shoot;
import java.util.Random;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.awt.Graphics;

public abstract class FlyingObject {
	//对象的状态，有三种
	public static final int LIFE = 0;
	public static final int DEAD = 1;
	public static final int REMOVE= 2;
	//默认状态为LIFE
	protected int state = LIFE;
	//飞行物的基本属性
	protected int width;
	protected int height;
	protected int x;
	protected int y;
	//为bullet和hero提供的构造方法
	FlyingObject(int width, int height ,int x, int y){
		this.width = width; 
		this.height = height;	
		this.x = x;
		this.y = y;
	}
	//为敌人提供的构造方法
	FlyingObject(int width, int height){
		this.width = width; 
		this.height = height;
		Random rand = new Random();
		x = rand.nextInt(ShootGamePlay.WIDTH - this.width);
		y = -this.height;
	}
	public static BufferedImage loadImage(String fileName) {
		try {
			BufferedImage img = ImageIO.read(FlyingObject.class.getResource(fileName));
			return img;
		}catch(Exception e){
			e.printStackTrace();
			throw new RuntimeException();
		}
	}
	//每种对象的图片获取方法不同，用抽象类
	public abstract void step ();	
	//获取图片
	public abstract BufferedImage getImage ();
	//判断状态
	public boolean isLife() {
		return state == LIFE;
	}
	public boolean isDead() {
		return state == DEAD;
	}
	public boolean isRemove() {
		return state == REMOVE;
	}
	//画对象,g是画笔
	public void paintObject(Graphics g) {
		g.drawImage(getImage(),x,y,null);
	}
	public boolean outOfBounds() {
		return this.y > ShootGamePlay.HEIGHT;
	}
	/*碰撞检测，敌人碰撞子弹或者hero*/
	public boolean hit(FlyingObject other) {
		int x1 = this.x - other.width;
		int x2 = this.x + this.height;
		int y1 = this.y - other.height;
		int y2 = this.y + this.height;
		int x = other.x;
		int y = other.y;
		return x >= x1 && x<= x2 && y >= y1 && y <= y2;
	}
	public void goDead() {
		state = DEAD;
	}
}
