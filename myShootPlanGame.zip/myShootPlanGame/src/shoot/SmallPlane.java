package shoot;

import java.awt.image.BufferedImage;

public class SmallPlane extends FlyingObject implements Enemy{
	 private static BufferedImage[] smallPlaneImages;
	 static {
		 //System.out.println(0);
		 smallPlaneImages = new BufferedImage[5];
		 for (int i = 0; i < smallPlaneImages.length; i++) {
			 smallPlaneImages[i] = loadImage("airplane"+i+".png");
		 }
	 }
	private int speed;
	SmallPlane(){
		super(49,36);
		speed = 2;
	}
	public void step() {
		y += speed;
	}
	int index = 1;//判断敌人到哪儿张图片了，如果是最后一张，将对象删除
	public BufferedImage getImage () {
		if (isLife()) {
			return smallPlaneImages[0];
		}else if (isDead()) {
			BufferedImage img = smallPlaneImages[index++];
			if(index == smallPlaneImages.length) {
				state = REMOVE;
			}
			return img;
		}
		return null;
	}
	//击败小敌机，得一分
	public int getScore() {
		return 1;
	}
}
