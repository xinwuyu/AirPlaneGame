package shoot;
import java.awt.image.BufferedImage;
public class BigPlane extends FlyingObject implements Enemy{
	private static BufferedImage[] bigPlaneImages;
	 static {
		 //System.out.println(0);
		 bigPlaneImages = new BufferedImage[5];
		 for (int i = 0; i < bigPlaneImages.length; i++) {
			 bigPlaneImages[i] = loadImage("bigplane"+i+".png");
		 }
	 }
	private int speed;
	BigPlane(){
		super(69,99);
		speed = 2;
	}
	public void step() {
		y += speed;
	}
	int index = 1;
	public BufferedImage getImage () {
		if (isLife()) {
			return bigPlaneImages[0];
		}else if (isDead()) {
			BufferedImage img = bigPlaneImages[index++];
			if(index == bigPlaneImages.length) {
				state = FlyingObject.REMOVE;
			}
			return img;
		}
		return null;
		
	}
	public int getScore() {
		return 3;
	}
}
