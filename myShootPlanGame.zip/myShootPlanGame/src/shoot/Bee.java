package shoot;

import java.awt.image.BufferedImage;
import java.util.Random;
public class Bee extends FlyingObject implements Award{
	private static BufferedImage[] beeImages;
	 static {
		 //System.out.println(0);
		 beeImages = new BufferedImage[5];
		 for (int i = 0; i < beeImages.length; i++) {
			 beeImages[i] = loadImage("bee"+i+".png");
		 }
	 }
	private int xspeed,yspeed;
	private int awardType;
	Bee(){
		super(60,50);
		xspeed = 1;
		yspeed = 2;
		Random rand = new Random();
		awardType = rand.nextInt(2);
	}
	public void step() {
		y += yspeed;
		x += xspeed;
		if (x <= 0 || x >= ShootGamePlay.WIDTH - this.width) {
			xspeed *= -1;
		}
	}
	int index = 1;
	public BufferedImage getImage () {
		if (isLife()) {
			return beeImages[0];
		}else if (isDead()) {
			BufferedImage img = beeImages[index++];
			if(index == beeImages.length) {
				state = REMOVE;
			}
			return img;
		}
		return null;
		
	}
	public int getAwardType() {
		return awardType;
	}
}
