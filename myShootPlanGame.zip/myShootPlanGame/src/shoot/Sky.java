package shoot;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Sky extends FlyingObject{
	private static BufferedImage skyImage;
	static {
		//System.out.println(1);
		skyImage = loadImage("background.png");
	}
	private int speed;
	private int y1;//第二张图片的y坐标
	Sky(){
		
		super(ShootGamePlay.WIDTH,ShootGamePlay.HEIGHT,0,0);
		speed = 1;
		y1 = -ShootGamePlay.HEIGHT;
	}
	//背景图片的移动
	public void step() {
		y += speed;
		y1 += speed;
		if (y > ShootGamePlay.HEIGHT) {
			y = -ShootGamePlay.HEIGHT;
		}
		if (y1 > ShootGamePlay.HEIGHT) {
			y1 = -ShootGamePlay.HEIGHT;
		}
	}
	//重写getImage
	public BufferedImage getImage () {
		return skyImage;
	}
	// 单独画两次SKY
	public void paintObject(Graphics g) {
		g.drawImage(getImage(),x,y,null);
		g.drawImage(getImage(),x,y1,null);
	}
	
}
