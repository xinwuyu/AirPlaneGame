/*
 * startTime = 2024/4/21
 * finishTime = 2024/4/30
 * author = "YuXinWu"
 * projectName = SkyBattle
 * */

/*
 *	Request ： 在SKY Scene上实现Hero 驾驶 MyPlane shoot missiles 
 *			   make collision with SmallPlane,BigPlane,Bee,
 *				If collision maked , above three object broken
 *				and hero scored，But MyPlane make collision with them
 *				loss a life
 *				First step : 找到对象
 *				Second step ： 从对象中抽象出对应的类
 *				Third Step ： 设计相应的变量和方法
 *				Forth Step ： 测试
 * 
*/

package shoot;
import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.Graphics;
//设计定时器
import java.util.Timer;
import java.util.TimerTask;
//生成随机数
import java.util.Random;
import java.util.Arrays;
// 鼠标监听器
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

public class ShootGamePlay extends JPanel{
	public static final int WIDTH = 400;
	public static final int HEIGHT = 700;
	
	public static final int START = 0;
	public static final int RUNNING = 1;
	public static final int PAUSE = 2;
	public static final int GAME_OVER = 3;
	private int state = START;
	private static BufferedImage start;
	private static BufferedImage pause;
	private static BufferedImage gameOver;
	static {
		start = FlyingObject.loadImage("start.png");
		pause = FlyingObject.loadImage("pause.png");
		gameOver = FlyingObject.loadImage("gameover.png");
	}
	private FlyingObject[] enemies = {
			new SmallPlane(),
			new BigPlane(),
			new Bee()
	};
	private Sky sky = new Sky();
	private Hero hero = new Hero(); 
	private Bullet[] bullet = {
			//new Bullet(8,16)
	}; 
	//生成三种敌人
	public FlyingObject nextone() {	

		Random rand = new Random();
		int type = rand.nextInt(20);
		if (type < 3) {
			return new Bee();
		}else if (type <13) {
			return new SmallPlane();
		}else {
			return new BigPlane();
		}
	}
	
	int enterIndex = 0;//敌人入场计数
	public void enterAction() {
		enterIndex ++;//每十毫秒调用一次增加一个
		if(enterIndex%100 == 0) {
			FlyingObject obj = nextone();  
			enemies = Arrays.copyOf(enemies, enemies.length+1);
			enemies[enemies.length - 1] = obj;
		}
	}
	//子弹入场
	int shootIndex = 0;
	public void shootAction() {
		shootIndex++;
		if(shootIndex%30 == 0) {
			Bullet[] bs = hero.shoot();
			bullet = Arrays.copyOf(bullet, bullet.length+bs.length);
			System.arraycopy(bs,0,bullet,bullet.length - bs.length,bs.length);
		}
	}
	//飞行物移动
	public void stepAction() {
		sky.step();
		for (int i = 0; i < enemies.length; i++) {
			enemies[i].step();
		}
		for (int i = 0; i < bullet.length; i++) {
			bullet[i].step();
		}
	}
	//删除越界的对象
	public void outOfBoundAction() {
		int index = 0;
		FlyingObject[] enemiesLive = new FlyingObject[enemies.length];
		for (int i = 0; i < enemies.length; i++) {
			FlyingObject f = enemies[i];//获取每个敌人
			if(!f.outOfBounds()&&!f.isRemove()) {
				enemiesLive[index++] = f;
			}
		}
		enemies = Arrays.copyOf(enemiesLive, index);
		index = 0;
		Bullet[] bulletLive = new Bullet[bullet.length];
		for (int i = 0; i < bullet.length; i++) {
			Bullet b = bullet[i];//获取子弹
			if(!b.outOfBounds()&&!b.isRemove()) {
				bulletLive[index++] = b;
			}
		}
		bullet = Arrays.copyOf(bulletLive, index);
	}
	
	int score = 0;//定义玩家得分
	public void bulletBangAction() {
		for (int i = 0; i < bullet.length; i++) {
			Bullet b = bullet[i];
			for (int j = 0; j < enemies.length; j++) {
				FlyingObject f = enemies[j];
				if(f.hit(b) && b.isLife() && f.isLife()) {
					f.goDead();
					b.goDead();
					if (f instanceof Enemy) {
						Enemy e = (Enemy)f;
						score += e.getScore();
					}
					if (f instanceof Award) {
						Award a = (Award)f;
						int type = a.getAwardType();
						switch(type){
							case Award.DOUBLE_FIRE:
								hero.addDoubleFire();
								break;
							case Award.LIFE:
								hero.addLife();
								break;
						}
					}
				}
			}
		}
	}
	//hero与enemies 碰撞
	public void heroBangAction() {
		for (int j = 0; j < enemies.length; j++) {
			FlyingObject f = enemies[j];
			if(f.hit(hero) && hero.isLife() && f.isLife()){
					f.goDead();
					hero.subtractLife();
					hero.clearDoubleFire();						
				}
			}
	}
	//结束游戏
	public void checkGameOverAction() {
		if (hero.getLife() <= 0) {
			state = GAME_OVER;
		}
	}
	public void action() {
		
			MouseAdapter l = new MouseAdapter() {
				public void mouseMoved(MouseEvent e) {
					int x = e.getX();
					int y = e.getY();
					hero.moveto(x, y);
				}
				public void mouseClicked(MouseEvent e) {
					//根据不同状态对鼠标点击做出不同的反应
					switch(state) {
					case START:
						state = RUNNING;
						break;
					case GAME_OVER:
						//清理现场
						score = 0;
						sky = new Sky();
						hero = new Hero();
						bullet = new Bullet[0];
						enemies = new FlyingObject[0];
						
						state = START;
						break;
					}
				}
				public void mouseExited(MouseEvent e) {
					if (state == RUNNING) {
						state = PAUSE;
					}
				}
				public void mouseEntered(MouseEvent e) {
					if (state == PAUSE) {
						state = RUNNING;
					}
				}
				
			};
			this.addMouseListener(l);
			this.addMouseMotionListener(l);
		
		
		Timer timer = new Timer();//定时器对象
		int interval = 10;//以毫秒为单位
		
		timer.schedule(new TimerTask(){
			public void run() {
				if (state == RUNNING) {
					enterAction();
					shootAction();
					outOfBoundAction();	
					stepAction();
					bulletBangAction();
					heroBangAction();
					checkGameOverAction();	
				}
				repaint();					
			}
				
		},interval, interval);
	}
		

	public void paint(Graphics g) {
		sky.paintObject(g);
		hero.paintObject(g);
		for (int i = 0; i < enemies.length; i++) {
			enemies[i].paintObject(g);
		}
		for (int i = 0; i < bullet.length; i++) {
			bullet[i].paintObject(g);
		}
		//在window上画出Score，位置为，(10,25)
		g.drawString("Score:"+score,10,25);
		g.drawString("Life:"+ hero.getLife(), 10, 45);
		//在不同状态画不同得状态图
		switch(state) {
			case START:
				g.drawImage(start, 0, 0, null);
				break;
			case PAUSE:
				g.drawImage(pause, 0, 0, null);
				break;
			case GAME_OVER:
				g.drawImage(gameOver, 0, 0, null);
				break;
		}
		
	}
	public static void main(String[] args) {
	
		// TODO Auto-generated method stub
		ShootGamePlay shootGamePlay = new ShootGamePlay();
		
		//shootGamePlay.action();
		//画框架
		JFrame frame = new JFrame();//实例化窗口
		frame.setTitle("--Sky Battle--");//设置标题
		frame.add(shootGamePlay);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(WIDTH,HEIGHT);
		//框架位置，默认为中心
		frame.setLocationRelativeTo(null);
		
		frame.setVisible(true);//尽快调用paint();
		shootGamePlay.action();
	}

}
/*错误情况一：
 * 这个错误信息表明您在Java程序中尝试从一个静态上下文（在这里是`main`方法）访问了一个非静态字段（成员变量），这是不允许的。错误信息中的两行分别指出：

1. `Cannot make a static reference to the non-static field shootGamePlay`
2. 同样的错误信息再次出现，可能是因为IDE或编译器重复报告了该错误。

具体到您的代码中，问题在于第31行，您可能尝试直接通过类名或在静态方法中访问了非静态字段`shootGamePlay`。在Java中，静态方法（如`main`方法）不能直接访问非静态字段或调用非静态方法，因为静态成员属于类级别，而非静态成员属于实例级别，它们需要通过类的实例来访问。

要解决这个问题，您可以：

- 如果`shootGamePlay`字段应该是静态的（即，它代表的是类级别的数据，而不是每个对象独立拥有的数据），那么修改其声明为`static`：

  ```java
  static ShootGamePlay shootGamePlay = new ShootGamePlay();
  ```

- 如果`shootGamePlay`需要维持为非静态的（即，每个`ShootGamePlay`实例应该有自己的这个字段），则不应该在静态方法如`main`中直接引用它。您应该创建一个`ShootGamePlay`的实例，并通过这个实例来访问`shootGamePlay`，但通常情况下直接实例化自己并在实例内部引用该实例是不合理的。如果您的目的是使用类的一个实例，应该直接创建并操作这个实例，而不是通过类字段自我引用。

请检查您的代码，在第31行及附近，寻找对`shootGamePlay`的引用，并根据上述原则进行修正。
 * */
 
