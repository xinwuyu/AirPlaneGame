module myShootPlanGame {
	requires java.desktop;
}